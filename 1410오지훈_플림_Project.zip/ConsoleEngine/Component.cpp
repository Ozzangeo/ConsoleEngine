#include "Component.h"

GameObject* Component::GetGameObject() {
    return gameobject;
}
