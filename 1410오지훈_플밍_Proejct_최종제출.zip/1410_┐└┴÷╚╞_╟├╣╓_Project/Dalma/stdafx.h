#ifndef _STDAFX_
#define _STDAFX_

#pragma comment(lib, "ConsoleEngine.lib")

#include "../ConsoleEngine/ConsoleEngine.h"
#include <sstream>
#include <filesystem>

#endif // !_STDAFX_
