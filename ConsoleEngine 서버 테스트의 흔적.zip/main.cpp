#pragma comment(lib, "ConsoleEngine.lib")
#include "../ConsoleEngine/ConsoleEngine.h"

#define IP "192.168.219.105"

class C : public Component {
private:
	Components::Server* server;

	void Awake() override {
		COORD size = { 8, 16 };
		graphic.SetScreenScale(size);
		size = { 64, 18 };
		graphic.SetScreenSize(size);
	}
	void Start() override {
		server = gameobject->GetComponent<Components::Server>();
		server->OpenServer(8080);
	}
	void Update() override {
		string msg = server->GetMsg();
		if (msg.length() > 0) { cout << msg << "\n"; }
	}
	void Remove() override {

	}
};

class B : public GameObject {
private:
	void Components() override {
		auto* a = AddComponent<Components::Server>();
		AddComponent<C>();
	}
};

class A : public Scene {
private:
	void GameObjects() override {
		AddGameObject<B>(L"Server");
	}
};

int main() {
	ConsoleEngine engine;

	engine.Run<A>();

	engine.Release();

	return 0;
}