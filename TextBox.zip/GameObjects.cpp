#include "GameObjects.h"

using namespace std;
using namespace Components;

void Box::Components() {
	auto* text = AddComponent<Text>();
}
