#include "Scenes.h"

void TextBox::GameObjects() {
	AddGameObject<Box>(L"Text", Tag_TextBox);
}
