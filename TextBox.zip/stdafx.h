#ifndef _STDAFX_
#define _STDAFX_

#pragma comment(lib, "ConsoleEngine.lib")
#include "../ConsoleEngine/ConsoleEngine.h"

#endif // !_STDAFX_
